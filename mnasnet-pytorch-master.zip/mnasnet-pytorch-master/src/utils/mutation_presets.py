mutations_presets = {
    0 : ['rect'],
    1 : ['elli'],    
    2 : ['elli','dlte'],
    3 : ['rect','dlte'],    
    4 : ['rect','elli','dlte'],    
    5 : ['rect','elli','dlte','dlto'],      
}